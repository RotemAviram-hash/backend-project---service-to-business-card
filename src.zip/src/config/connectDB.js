import mongoose from "mongoose";
import printMessage from "../utils/printMessage.js";

const connectDB = async () => {
  try {
    const mongoUri =
      process.env.NODE_ENV === "atlas"
        ? process.env.MONGO_URI_ATLAS
        : process.env.MONGO_URI_LOCAL;

    const conn = await mongoose.connect(mongoUri);

    printMessage(`MongoDB Connected: ${conn.connection.host}`, "success");
  } catch (error) {
    printMessage(`Error: ${error.message}`, "error");
    process.exit(1);
  }
};

export default connectDB;
